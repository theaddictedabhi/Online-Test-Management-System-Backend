export enum GenreType {
    Drama = 0,
    Fiction,
    Satire
}