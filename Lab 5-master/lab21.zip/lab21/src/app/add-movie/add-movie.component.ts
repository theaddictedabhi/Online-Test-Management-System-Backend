import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MovieInfo } from '../models/movie-info.model';
import { MovieAppService } from '../movie-app.service';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-add-movie',
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent implements OnInit {
  movieInfo: FormGroup;

  constructor(private movieAppService: MovieAppService) { }

  ngOnInit() {
    this.buildReactiveForm();
  }

  buildReactiveForm(){
    this.movieInfo =  new FormGroup({
      name: new FormControl(''),
      rating: new FormControl(''),
      genre: new FormControl(null)
    });
  }

  addNewMovie(){
    let newMovie = new MovieInfo(this.movieInfo.value);
    this.movieAppService.addNewMovie(newMovie);
    alert('new movie added');
    this.movieInfo.reset();
  }

}
